import 'package:flutter/material.dart';
import 'package:untitled/screen/login.dart';



void main(){

  runApp(s());
}