import 'package:flutter/material.dart';

class s extends StatefulWidget {
  const s({Key? key}) : super(key: key);

  @override
  _sState createState() => _sState();
}
class _sState extends State<s> {
    var  x = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
        debugShowCheckedModeBanner: false,
        home:Scaffold(


            body: Form(

                         key: x,
                child:Container(
                  color: Colors.black,
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Column(


                mainAxisAlignment: MainAxisAlignment.center,


                children: [


                  SizedBox(height: 30,),

                  login(),
                  SizedBox(height: 60,),

                  password(),

                  SizedBox(height: 60,),

                  Container(

                      width: 100,
                      height: 50,

                      decoration: BoxDecoration(
                          border: Border.all(

                          ),

                          borderRadius: BorderRadius.all(
                              Radius.circular(25.0))),
                      child: ElevatedButton( onPressed: (){

                        x.currentState!.validate();

                      }, child: Text("Login"),
                      )
                  )


                  ],),
              /*color: Colors.black,

           */
              width: double.infinity,

              height: double.infinity,




            )

            )
        ));}
}

Widget login(){


  return TextFormField(

      validator: (value) {

        if (value == null || value.isEmpty) {
          return 'Please enter some text';
        }
        else if( value.length==9 ){
          return "need 10 number";

        }


      },

      style: TextStyle(fontSize: 18) ,
      cursorColor: Colors.red,

      decoration: InputDecoration(fillColor: Colors.red,hintText: "email,phone",prefixIcon: Icon(Icons.login),
        filled: true ,
        border: new OutlineInputBorder(
          borderRadius: new BorderRadius.circular(25.0),
          borderSide: new BorderSide(color: Colors.red),  ),
      ));
}

Widget  password(){


  return TextFormField(

    validator:  (value)
    {
      if(value?.length==0)
      {
        return "need a password ";
      }

    },
    obscureText: true,
    style: TextStyle(fontSize: 18) ,
    cursorColor: Colors.red,
    decoration: InputDecoration(fillColor: Colors.red,hintText: "Password",prefixIcon: Icon(Icons.security),
      filled: true,

      border:new OutlineInputBorder(  borderRadius:new BorderRadius.circular(25)
      ),


    ),
  );
}



void main(){


  runApp(s());

}
